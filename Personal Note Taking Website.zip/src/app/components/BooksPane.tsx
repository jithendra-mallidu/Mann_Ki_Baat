import { Book, Plus } from 'lucide-react';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';

export interface BookType {
  id: string;
  name: string;
  noteCount: number;
}

interface BooksPaneProps {
  books: BookType[];
  selectedBookId: string | null;
  onSelectBook: (bookId: string) => void;
  onAddBook: () => void;
}

export function BooksPane({ books, selectedBookId, onSelectBook, onAddBook }: BooksPaneProps) {
  return (
    <div className="w-64 bg-[#2d2a2e] h-screen flex flex-col border-r border-gray-800">
      {/* Header */}
      <div className="p-4 border-b border-gray-800">
        <h2 className="text-white/60 text-sm mb-1">Library</h2>
        <h1 className="text-white">My Books</h1>
      </div>

      {/* Books List */}
      <ScrollArea className="flex-1 p-2">
        <div className="space-y-1">
          {books.map((book) => (
            <button
              key={book.id}
              onClick={() => onSelectBook(book.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                selectedBookId === book.id
                  ? 'bg-[#e9b44c] text-[#2d2a2e]'
                  : 'text-white/80 hover:bg-white/10'
              }`}
            >
              <Book className="w-4 h-4 flex-shrink-0" />
              <div className="flex-1 text-left">
                <div className="text-sm truncate">{book.name}</div>
              </div>
              <div className={`text-xs px-2 py-0.5 rounded ${
                selectedBookId === book.id
                  ? 'bg-[#2d2a2e] text-white'
                  : 'bg-white/10 text-white/60'
              }`}>
                {book.noteCount}
              </div>
            </button>
          ))}
        </div>
      </ScrollArea>

      {/* Add Book Button */}
      <div className="p-4 border-t border-gray-800">
        <Button
          onClick={onAddBook}
          variant="outline"
          className="w-full bg-transparent border-white/20 text-white hover:bg-white/10 hover:text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Book
        </Button>
      </div>
    </div>
  );
}
