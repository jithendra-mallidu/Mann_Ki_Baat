import { useState } from 'react';
import { LoginPage } from './components/LoginPage';
import { BooksPane, BookType } from './components/BooksPane';
import { ChaptersPane, ChapterType } from './components/ChaptersPane';
import { NotesPane, NoteType, TagType } from './components/NotesPane';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [books, setBooks] = useState<BookType[]>([
    { id: '1', name: 'Personal Notes', noteCount: 5 },
    { id: '2', name: 'Work Projects', noteCount: 12 },
    { id: '3', name: 'Learning Resources', noteCount: 8 },
  ]);
  const [chapters, setChapters] = useState<ChapterType[]>([
    { id: '1', name: 'Product_Siksha', date: '12/14/25', bookId: '1' },
    { id: '2', name: 'ADHIRA - (Toys, Apparel)', date: '12/12/25', bookId: '1' },
    { id: '3', name: 'Meeting Notes - Q4 2024', date: '12/10/25', bookId: '2' },
  ]);
  const [notes, setNotes] = useState<NoteType[]>([
    { 
      id: '1', 
      date: 'Jan 17, 2025', 
      content: 'H-1B Modernization Rule Effective\n\nThe final rule takes effect, implementing significant changes to the lottery and registration process to address fraud in the selection system. It also modernizes requirements for H-1B and H-2 programs.',
      chapterId: '1' 
    },
    { 
      id: '2', 
      date: 'Sep 06, 2025', 
      content: 'End of Third Country National Processing\n\nHover for details',
      chapterId: '1' 
    },
  ]);
  const [tags, setTags] = useState<TagType[]>([
    { id: '1', name: 'DHS / USCIS', color: 'bg-blue-500' },
    { id: '2', name: 'White House', color: 'bg-red-500' },
    { id: '3', name: 'DOL', color: 'bg-yellow-500' },
    { id: '4', name: 'State Dept', color: 'bg-teal-500' },
  ]);

  const [selectedBookId, setSelectedBookId] = useState<string | null>('1');
  const [selectedChapterId, setSelectedChapterId] = useState<string | null>('1');

  const handleAddBook = () => {
    const bookName = prompt('Enter book name:');
    if (bookName) {
      const newBook: BookType = {
        id: Date.now().toString(),
        name: bookName,
        noteCount: 0,
      };
      setBooks([...books, newBook]);
    }
  };

  const handleAddChapter = () => {
    if (!selectedBookId) {
      alert('Please select a book first');
      return;
    }
    const chapterName = prompt('Enter chapter name:');
    if (chapterName) {
      const today = new Date();
      const dateStr = `${today.getMonth() + 1}/${today.getDate()}/${today.getFullYear().toString().slice(-2)}`;
      const newChapter: ChapterType = {
        id: Date.now().toString(),
        name: chapterName,
        date: dateStr,
        bookId: selectedBookId,
      };
      setChapters([...chapters, newChapter]);
    }
  };

  const handleAddNote = (content: string, date: string) => {
    if (!selectedChapterId) {
      alert('Please select a chapter first');
      return;
    }
    const newNote: NoteType = {
      id: Date.now().toString(),
      date,
      content,
      chapterId: selectedChapterId,
    };
    setNotes([newNote, ...notes]);

    // Update book note count
    const chapter = chapters.find(c => c.id === selectedChapterId);
    if (chapter) {
      setBooks(books.map(book => 
        book.id === chapter.bookId 
          ? { ...book, noteCount: book.noteCount + 1 }
          : book
      ));
    }
  };

  const handleAddTag = (name: string, color: string) => {
    const newTag: TagType = {
      id: Date.now().toString(),
      name,
      color,
    };
    setTags([...tags, newTag]);
  };

  const handleRemoveTag = (tagId: string) => {
    setTags(tags.filter(tag => tag.id !== tagId));
  };

  if (!isLoggedIn) {
    return <LoginPage onLogin={() => setIsLoggedIn(true)} />;
  }

  const selectedBook = books.find(b => b.id === selectedBookId);
  const selectedChapter = chapters.find(c => c.id === selectedChapterId);
  const filteredChapters = chapters.filter(c => c.bookId === selectedBookId);
  const filteredNotes = notes.filter(n => n.chapterId === selectedChapterId);

  return (
    <div className="flex h-screen overflow-hidden">
      <BooksPane
        books={books}
        selectedBookId={selectedBookId}
        onSelectBook={setSelectedBookId}
        onAddBook={handleAddBook}
      />
      <ChaptersPane
        chapters={filteredChapters}
        selectedChapterId={selectedChapterId}
        onSelectChapter={setSelectedChapterId}
        onAddChapter={handleAddChapter}
        selectedBookName={selectedBook?.name || ''}
      />
      <NotesPane
        notes={filteredNotes}
        tags={tags}
        selectedChapterName={selectedChapter?.name || ''}
        onAddNote={handleAddNote}
        onAddTag={handleAddTag}
        onRemoveTag={handleRemoveTag}
      />
    </div>
  );
}
